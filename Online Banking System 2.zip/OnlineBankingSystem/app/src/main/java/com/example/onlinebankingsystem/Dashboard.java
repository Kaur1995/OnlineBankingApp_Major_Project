package com.example.onlinebankingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Dashboard extends AppCompatActivity {
    TextView name;
    TextView balance;
    TextView accountID;
    ListView listOfAccounts;

    Button UBButton;
    Button SMButton;
    ArrayAdapter adapter;
    String cardNo;
    //static DataClass dc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        name = (TextView) findViewById(R.id.textViewName);
        balance = (TextView) findViewById(R.id.textViewBalance);
        accountID = (TextView) findViewById(R.id.textViewAccountID);
        listOfAccounts = (ListView) findViewById(R.id.listOfAccounts);
        UBButton = (Button) findViewById(R.id.UBButton);
        SMButton = (Button) findViewById(R.id.SMButton);

        Intent incomingIntent = getIntent();
        cardNo = incomingIntent.getStringExtra("AcessCardID");
        final ArrayList<String> listoAcc = new ArrayList<>();
        //dc = new DataClass();
        if(HomeActivity.dc.getA1().getAccessCardNumber().equals(cardNo)){
            name.setText(HomeActivity.dc.getA1().getName());
            balance.setText("Balance: "+String.valueOf(HomeActivity.dc.getA1().getListOfAccounts().get(0).getBalance()));
            accountID.setText("Account ID: "+HomeActivity.dc.getA1().getListOfAccounts().get(0).accountID);
                for(Accounts a:HomeActivity.dc.getA1().getListOfAccounts()){
                    listoAcc.add("Account No: "+a.getAccountID());
                }
                adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listoAcc);
                listOfAccounts.setAdapter(adapter);
            listOfAccounts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    for( int j =0;j<listOfAccounts.getChildCount();j++){
                        listOfAccounts.getChildAt(j).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
                    }
                    listOfAccounts.getChildAt(i).setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
                    balance.setText("Balance: "+String.valueOf(HomeActivity.dc.getA1().getListOfAccounts().get(i).getBalance()));
                    accountID.setText("Account ID: "+HomeActivity.dc.getA1().getListOfAccounts().get(i).accountID);
                }
            });
        }else if (HomeActivity.dc.getA2().getAccessCardNumber().equals(cardNo)){
            name.setText(HomeActivity.dc.getA2().getName());
            balance.setText("Balance: "+String.valueOf(HomeActivity.dc.getA2().getListOfAccounts().get(0).getBalance()));
            accountID.setText("Account ID: "+HomeActivity.dc.getA2().getListOfAccounts().get(0).accountID);
            for(Accounts a:HomeActivity.dc.getA2().getListOfAccounts()){
                listoAcc.add("Account No: "+a.getAccountID());
            }
            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listoAcc);
            listOfAccounts.setAdapter(adapter);
            listOfAccounts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    for( int j =0;j<listOfAccounts.getChildCount();j++){
                        listOfAccounts.getChildAt(j).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
                    }
                    listOfAccounts.getChildAt(i).setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
                    balance.setText("Balance: "+String.valueOf(HomeActivity.dc.getA2().getListOfAccounts().get(i).getBalance()));
                    accountID.setText("Account ID: "+HomeActivity.dc.getA2().getListOfAccounts().get(i).accountID);
                }
            });

        }else if (HomeActivity.dc.getA3().getAccessCardNumber().equals(cardNo)){
            name.setText(HomeActivity.dc.getA3().getName());
            balance.setText("Balance: "+String.valueOf(HomeActivity.dc.getA3().getListOfAccounts().get(0).getBalance()));
            accountID.setText("Account ID: "+HomeActivity.dc.getA3().getListOfAccounts().get(0).accountID);
            for(Accounts a:HomeActivity.dc.getA3().getListOfAccounts()){
                listoAcc.add("Account No: "+a.getAccountID());
            }
            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listoAcc);
            listOfAccounts.setAdapter(adapter);
            listOfAccounts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    for( int j =0;j<listOfAccounts.getChildCount();j++){
                        listOfAccounts.getChildAt(j).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
                    }
                    listOfAccounts.getChildAt(i).setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
                    balance.setText("Balance: "+String.valueOf(HomeActivity.dc.getA3().getListOfAccounts().get(i).getBalance()));
                    accountID.setText("Account ID: "+HomeActivity.dc.getA3().getListOfAccounts().get(i).accountID);
                }
            });
        }
        UBButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Dashboard.this,UtilityBills.class);
                if(HomeActivity.dc.getA1().getAccessCardNumber().equals(cardNo) ){
                    intent.putExtra("AcessCardID",HomeActivity.dc.getA1().getAccessCardNumber());
                }else if(HomeActivity.dc.getA2().getAccessCardNumber().equals(cardNo) ){
                    intent.putExtra("AcessCardID",cardNo);
                }else if(HomeActivity.dc.getA3().getAccessCardNumber().equals(cardNo)){
                    intent.putExtra("AcessCardID",cardNo);
                }else{

                }

                startActivity(intent);
            }
        });

        SMButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this,SendMoney.class);
                startActivity(intent);
            }
        });

        configureBackButton();
    }

    public void configureBackButton(){

    }
}
