package com.example.onlinebankingsystem;

import java.util.ArrayList;

public class AccountHolders {
    String name;
    String accessCardNumber;
    int pinCode;
    ArrayList<Accounts> listOfAccounts;

    public AccountHolders(String name, String accessCardNumber, int pinCode) {
        this.name = name;
        this.accessCardNumber = accessCardNumber;
        this.pinCode = pinCode;
        this.listOfAccounts = new ArrayList<>();
    }
    public void add(Accounts a){
        listOfAccounts.add(a);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccessCardNumber() {
        return accessCardNumber;
    }

    public void setAccessCardNumber(String accessCardNumber) {
        this.accessCardNumber = accessCardNumber;
    }

    public int getPinCode() {
        return pinCode;
    }

    public void setPinCode(int pinCode) {
        this.pinCode = pinCode;
    }

    public ArrayList<Accounts> getListOfAccounts() {
        return listOfAccounts;
    }

    public void setListOfAccounts(ArrayList<Accounts> listOfAccounts) {
        this.listOfAccounts = listOfAccounts;
    }
}
